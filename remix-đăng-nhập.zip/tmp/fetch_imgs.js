async function testFetch(url) {
  try {
    const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    if (!res.ok) return null;
    const text = await res.text();
    const regex = /(https?:\/\/[^\s"'<>]+?\.(?:jpg|jpeg|png|webp))/gi;
    const matches = text.match(regex) || [];
    return matches;
  } catch (err) {
    return null;
  }
}

async function main() {
  const urls = [
    'https://gaohouse.vn/san-pham/ao-lop-baseball-dream-big/',
    'https://dongphuchaianh.vn/ao-lop-cheerful/',
    'https://dongphuchaianh.vn/mau-ao-dong-phuc-lop-so-mi-oversize-sparkling-mau-xanh-than-2/',
    'https://gaohouse.vn/san-pham/ao-dong-phuc-thiet-ke-gum1970030/'
  ];

  for (const u of urls) {
    console.log('Fetching:', u);
    const matches = await testFetch(u);
    if (matches) {
      const filtered = matches.filter(m => /dream-big|cheerful|sparkling|gum1970030/i.test(m));
      console.log('Found:', filtered);
    }
  }
}

main();

